use fractal_core::GeneratorKind;
use wgpu::{ComputePipeline, Device, ShaderModule, Texture};

/// One compute pipeline per generator variant.
pub struct GeneratorPipelines {
    pub mandelbrot: ComputePipeline,
    pub julia: ComputePipeline,
    pub burning_ship: ComputePipeline,
    pub noise_field: ComputePipeline,
}

impl GeneratorPipelines {
    pub fn new(device: &Device) -> Self {
        Self {
            mandelbrot:   make_pipeline(device, "mandelbrot",   include_str!("../shaders/mandelbrot.wgsl")),
            julia:        make_pipeline(device, "julia",        include_str!("../shaders/julia.wgsl")),
            burning_ship: make_pipeline(device, "burning_ship", include_str!("../shaders/burning_ship.wgsl")),
            noise_field:  make_pipeline(device, "noise_field",  include_str!("../shaders/noise_field.wgsl")),
        }
    }

    pub fn get(&self, kind: GeneratorKind) -> &ComputePipeline {
        match kind {
            GeneratorKind::Mandelbrot  => &self.mandelbrot,
            GeneratorKind::Julia       => &self.julia,
            GeneratorKind::BurningShip => &self.burning_ship,
            GeneratorKind::NoiseField  => &self.noise_field,
        }
    }
}

fn make_pipeline(device: &Device, label: &str, wgsl: &str) -> ComputePipeline {
    let module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some(label),
        source: wgpu::ShaderSource::Wgsl(wgsl.into()),
    });
    device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
        label: Some(label),
        layout: None,
        module: &module,
        entry_point: Some("main"),
        compilation_options: Default::default(),
        cache: None,
    })
}
